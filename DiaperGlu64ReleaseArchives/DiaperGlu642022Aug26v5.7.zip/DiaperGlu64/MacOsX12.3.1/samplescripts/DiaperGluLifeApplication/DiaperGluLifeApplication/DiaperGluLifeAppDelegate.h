//
//  DiaperGluLifeAppDelegate.h
//  DiaperGluLifeApplication
//
//  Created by James Norris on 4/3/18.
//  Copyright (c) 2018 James Norris. All rights reserved.
//

@interface DiaperGluLifeAppDelegate : NSObject <NSApplicationDelegate>

- (void)sendDoLifeMessage;

@property (assign) IBOutlet NSWindow *window;

@end
