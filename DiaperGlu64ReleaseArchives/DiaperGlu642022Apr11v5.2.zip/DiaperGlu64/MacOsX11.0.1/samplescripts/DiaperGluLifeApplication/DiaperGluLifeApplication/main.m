//
//  main.m
//  DiaperGluLifeApplication
//
//  Created by James Norris on 4/3/18.
//  Copyright (c) 2018 James Norris. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
