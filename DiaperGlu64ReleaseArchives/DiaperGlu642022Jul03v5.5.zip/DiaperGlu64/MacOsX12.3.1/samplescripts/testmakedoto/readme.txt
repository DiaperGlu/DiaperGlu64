change directory to this directory

do sudo make

after make finishes, do ./test

then do ./testmakedotolinked

the makefile uses diaperglu on a .dglu file to build a .o file

the makefile also uses ld to make a .dylib

